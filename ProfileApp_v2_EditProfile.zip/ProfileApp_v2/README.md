# ProfileApp (Kotlin + Jetpack Compose + Material 3)

Halaman **Profile** dan **Edit Profile** bergaya Instagram, mengikuti desain referensi (putih, teks hitam/abu, tombol ungu keabu-abuan #5E5A7A).

## Menjalankan
1. Android Studio (Koala+, JDK 17) → **File → Open** → pilih folder `ProfileApp` → tunggu Gradle sync (butuh internet).
2. Emulator: buat di Device Manager lalu klik **Run ▶**. HP fisik: aktifkan USB debugging, sambungkan, pilih perangkat, **Run ▶**.
3. APK: **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.

## Struktur file (app/src/main/java/com/example/profileapp/)
- `MainActivity.kt` — Activity + NavHost (profile ↔ edit)
- `ProfileViewModel.kt` — state Compose + simpan otomatis
- `data/ProfileData.kt` — model, SharedPreferences, data contoh
- `ui/theme/Theme.kt` — warna & tema Material 3
- `ui/components/Components.kt` — Avatar, input berlabel, dropdown, tile galeri
- `ui/screens/ProfileScreen.kt`, `ui/screens/EditProfileScreen.kt`

## Jika ingin dipakai di proyek yang sudah ada
Salin folder `data`, `ui`, `MainActivity.kt`, `ProfileViewModel.kt` ke package proyek Anda dan ganti baris `package com.example.profileapp` sesuai package Anda. Pastikan dependency di `app/build.gradle.kts` (Compose BOM, material3, material-icons-extended, navigation-compose, lifecycle-viewmodel-compose, activity-compose) dan `buildFeatures { compose = true }` + `composeOptions` sudah ada. Manifest: cukup `android:windowSoftInputMode="adjustResize"` pada activity.

## Fitur
Edit nama/username/bio/contact/kategori (dropdown) → **Save Changes** → Toast "Data berhasil disimpan" → kembali ke Profile dan data langsung berubah; tersimpan permanen (SharedPreferences). Follow ⇄ Following (juga tersimpan). Tombol share membuka share sheet. Statistik, highlights, dan galeri 3 kolom memakai data contoh dan placeholder bergambar (tanpa foto asli).

---
## Pembaruan v2 — Profil bisa diedit penuh (termasuk foto)
File **baru**: `data/ImageUtils.kt`
File **diganti**: `data/ProfileData.kt`, `ProfileViewModel.kt`, `ui/screens/EditProfileScreen.kt`
File **diubah sebagian**: `ui/components/Components.kt` (Avatar bisa menampilkan foto), `ui/screens/ProfileScreen.kt` (foto + ikon pensil di avatar), `MainActivity.kt` (parameter onSave)
Tidak ada dependency baru dan tidak perlu izin tambahan (memakai Android Photo Picker).

Cara pakai: Profile → ketuk avatar (ikon pensil) atau tombol "Edit Profile" → ketuk foto / "Change Photo" untuk memilih dari galeri ("Remove" untuk menghapus) → ubah Name, Username, Bio, Contact, Category → **Save Changes**.

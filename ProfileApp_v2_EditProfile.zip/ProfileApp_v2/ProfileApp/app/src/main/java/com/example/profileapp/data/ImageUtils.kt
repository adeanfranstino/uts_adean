package com.example.profileapp.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.InputStream
import kotlin.math.min

/** Membaca gambar (Uri atau path file), memperbaiki rotasi EXIF, memotong persegi, dan mengecilkannya. */
object ImageUtils {
    private fun open(context: Context, source: Any): InputStream? = when (source) {
        is Uri -> context.contentResolver.openInputStream(source)
        is String -> File(source).inputStream()
        else -> null
    }

    fun decode(context: Context, source: Any, maxSize: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(context, source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > maxSize * 2 || bounds.outHeight / sample > maxSize * 2) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = open(context, source)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (raw == null) null else {
            val degrees = try {
                open(context, source)?.use {
                    when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) { 0f }

            val side = min(raw.width, raw.height)
            val matrix = Matrix().apply { postRotate(degrees) }
            val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side, matrix, true)
            val target = min(square.width, maxSize)
            Bitmap.createScaledBitmap(square, target, target, true)
        }
    } catch (e: Exception) { null }
}

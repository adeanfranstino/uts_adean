package com.example.profileapp.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddBox
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.profileapp.data.SampleData
import com.example.profileapp.data.UserProfile
import com.example.profileapp.ui.components.Avatar
import com.example.profileapp.ui.components.GalleryTile
import com.example.profileapp.ui.theme.BorderGray
import com.example.profileapp.ui.theme.InkBlack
import com.example.profileapp.ui.theme.InkGray
import com.example.profileapp.ui.theme.PurpleGray

@Composable
fun ProfileScreen(profile: UserProfile, onEdit: () -> Unit, onToggleFollow: () -> Unit) {
    val context = LocalContext.current
    Scaffold(containerColor = Color.White, bottomBar = { BottomNav(context) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            CoverWithAvatar(profile.photoPath, onEdit)
            Spacer(Modifier.height(52.dp))

            Text(
                profile.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = InkBlack,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "@${profile.username} • ${profile.category}", fontSize = 13.sp, color = InkGray,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
            )
            Text(
                profile.bio, fontSize = 13.sp, lineHeight = 18.sp, color = InkGray,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 8.dp)
            )
            if (profile.contact.isNotBlank()) {
                Text(profile.contact, fontSize = 12.sp, color = PurpleGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                if (profile.isFollowing) {
                    OutlinedButton(
                        onClick = onToggleFollow,
                        modifier = Modifier.width(170.dp).height(44.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleGray)
                    ) { Text("Following", color = PurpleGray, fontWeight = FontWeight.SemiBold) }
                } else {
                    Button(
                        onClick = onToggleFollow,
                        modifier = Modifier.width(170.dp).height(44.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleGray, contentColor = Color.White)
                    ) { Text("Follow", fontWeight = FontWeight.SemiBold) }
                }
                Spacer(Modifier.width(12.dp))
                IconButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Lihat profil @${profile.username} (${profile.name})")
                    }
                    context.startActivity(Intent.createChooser(send, "Bagikan profil"))
                }) { Icon(Icons.Outlined.Share, contentDescription = "Bagikan", tint = InkBlack) }
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(SampleData.POSTS, "Posts")
                Stat(SampleData.FOLLOWERS, "Followers")
                Stat(SampleData.FOLLOWING, "Following")
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Highlights", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkBlack)
                Text(
                    "View All", fontSize = 13.sp, color = InkGray,
                    modifier = Modifier.clickable { Toast.makeText(context, "Semua sorotan (data contoh)", Toast.LENGTH_SHORT).show() }
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                SampleData.highlights.forEach { label ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(68.dp).border(2.dp, PurpleGray.copy(alpha = 0.5f), CircleShape).padding(4.dp)) { Avatar(60.dp) }
                        Spacer(Modifier.height(4.dp))
                        Text(label, fontSize = 12.sp, color = InkBlack)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.GridOn, contentDescription = null, tint = InkBlack, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Posts", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = InkBlack)
            }
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                SampleData.gallery.chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        rowItems.forEach { c ->
                            GalleryTile(c, Modifier.weight(1f).aspectRatio(1f).clickable {
                                Toast.makeText(context, "Postingan (data contoh)", Toast.LENGTH_SHORT).show()
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CoverWithAvatar(photoPath: String?, onEdit: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(150.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFC9CDD6), Color(0xFFE6E8ED))))
            val w = size.width
            val h = size.height
            val back = Path().apply {
                moveTo(0f, h); lineTo(0f, h * 0.55f); lineTo(w * 0.25f, h * 0.30f); lineTo(w * 0.50f, h * 0.60f)
                lineTo(w * 0.75f, h * 0.25f); lineTo(w, h * 0.55f); lineTo(w, h); close()
            }
            val front = Path().apply {
                moveTo(0f, h); lineTo(0f, h * 0.80f); lineTo(w * 0.30f, h * 0.55f); lineTo(w * 0.60f, h * 0.85f)
                lineTo(w * 0.85f, h * 0.60f); lineTo(w, h * 0.80f); lineTo(w, h); close()
            }
            drawPath(back, Color(0xFFA3A8B4))
            drawPath(front, Color(0xFF7F8592))
            drawCircle(Color.White.copy(alpha = 0.7f), radius = h * 0.12f, center = Offset(w * 0.82f, h * 0.2f))
        }
        Text(
            "Edit Profile", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = InkBlack,
            modifier = Modifier
                .align(Alignment.TopEnd).padding(12.dp)
                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(20.dp))
                .clickable(onClick = onEdit)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
        Box(Modifier.align(Alignment.BottomCenter).offset(y = 48.dp).clickable(onClick = onEdit)) {
            Avatar(size = 96.dp, borderWidth = 4.dp, model = photoPath)
            Box(
                Modifier.align(Alignment.BottomEnd).size(30.dp)
                    .background(PurpleGray, CircleShape).border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Outlined.Edit, contentDescription = "Edit profil", tint = Color.White, modifier = Modifier.size(15.dp)) }
        }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = InkBlack)
        Text(label, fontSize = 12.sp, color = InkGray)
    }
}

@Composable
private fun BottomNav(context: Context) {
    val items: List<Pair<ImageVector, String>> = listOf(
        Icons.Outlined.Home to "Home", Icons.Outlined.Search to "Search", Icons.Outlined.AddBox to "Add Post",
        Icons.Outlined.VideoLibrary to "Reels", Icons.Outlined.Person to "Profile"
    )
    NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
        items.forEachIndexed { index, (icon, label) ->
            NavigationBarItem(
                selected = index == items.lastIndex,
                onClick = {
                    if (index != items.lastIndex) Toast.makeText(context, "$label: hanya contoh tampilan", Toast.LENGTH_SHORT).show()
                },
                icon = { Icon(icon, contentDescription = label) },
                alwaysShowLabel = false,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = InkBlack, unselectedIconColor = InkGray, indicatorColor = BorderGray.copy(alpha = 0.5f)
                )
            )
        }
    }
}

package com.example.profileapp.data

import android.content.Context
import android.net.Uri
import androidx.compose.ui.graphics.Color
import java.io.File

data class UserProfile(
    val name: String,
    val username: String,
    val bio: String,
    val contact: String,
    val category: String,
    val isFollowing: Boolean,
    val photoPath: String? = null
)

/** Hasil dari form Edit Profile. */
data class ProfileEdit(
    val name: String,
    val username: String,
    val bio: String,
    val contact: String,
    val category: String,
    val newPhoto: Uri?,
    val removePhoto: Boolean
)

/** Penyimpanan lokal profil memakai SharedPreferences + foto di folder internal aplikasi. */
class ProfileRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)

    fun load(): UserProfile {
        val photo = prefs.getString("photo", null)?.takeIf { File(it).exists() }
        return UserProfile(
            name = prefs.getString("name", "Devon Lane") ?: "Devon Lane",
            username = prefs.getString("username", "devonlane") ?: "devonlane",
            bio = prefs.getString(
                "bio",
                "Passionate adventurer who loves to explore the world, capture moments, and share stories."
            ) ?: "",
            contact = prefs.getString("contact", "devonlane@gmail.com") ?: "",
            category = prefs.getString("category", "Photographer") ?: "Photographer",
            isFollowing = prefs.getBoolean("following", false),
            photoPath = photo
        )
    }

    fun save(p: UserProfile) {
        prefs.edit()
            .putString("name", p.name).putString("username", p.username)
            .putString("bio", p.bio).putString("contact", p.contact)
            .putString("category", p.category).putBoolean("following", p.isFollowing)
            .putString("photo", p.photoPath)
            .apply()
    }

    /** Salin foto pilihan ke penyimpanan internal (persegi 512px). Mengembalikan path, atau null jika gagal. */
    fun storePhoto(uri: Uri): String? {
        val bmp = ImageUtils.decode(appContext, uri, 512) ?: return null
        val file = File(appContext.filesDir, "profile_${System.currentTimeMillis()}.jpg")
        return try {
            file.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            file.absolutePath
        } catch (e: Exception) { null }
    }

    fun deletePhoto(path: String?) {
        if (path != null) runCatching { File(path).delete() }
    }
}

/** Data contoh untuk statistik, sorotan, dan galeri. */
object SampleData {
    const val POSTS = "205"
    const val FOLLOWERS = "205K"
    const val FOLLOWING = "870"

    val categories = listOf("Photographer", "Traveler", "Artist", "Musician", "Blogger", "Athlete", "Chef", "Developer", "Other")
    val highlights = listOf("Travel", "Food", "Friends", "Music", "Sport")

    val gallery: List<Pair<Color, Color>> = listOf(
        Color(0xFF9EA3AE) to Color(0xFF6F7480), Color(0xFFB9BDC6) to Color(0xFF8B909C),
        Color(0xFF7D828E) to Color(0xFF555A66), Color(0xFFC9CCD3) to Color(0xFFA3A7B1),
        Color(0xFF8F94A0) to Color(0xFF666B77), Color(0xFFABAFB8) to Color(0xFF7C818D),
        Color(0xFFD2D4DA) to Color(0xFFAEB2BB), Color(0xFF858A96) to Color(0xFF5B606C),
        Color(0xFFB1B5BE) to Color(0xFF868B97)
    )
}

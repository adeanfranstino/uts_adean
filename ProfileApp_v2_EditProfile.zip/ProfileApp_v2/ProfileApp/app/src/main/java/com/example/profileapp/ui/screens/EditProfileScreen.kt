package com.example.profileapp.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.profileapp.data.ProfileEdit
import com.example.profileapp.data.SampleData
import com.example.profileapp.data.UserProfile
import com.example.profileapp.ui.components.Avatar
import com.example.profileapp.ui.components.CategoryDropdown
import com.example.profileapp.ui.components.LabeledField
import com.example.profileapp.ui.theme.InkBlack
import com.example.profileapp.ui.theme.InkGray
import com.example.profileapp.ui.theme.PurpleGray

@Composable
fun EditProfileScreen(
    profile: UserProfile,
    onSave: (ProfileEdit, (Boolean) -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var name by remember(profile) { mutableStateOf(profile.name) }
    var username by remember(profile) { mutableStateOf(profile.username) }
    var bio by remember(profile) { mutableStateOf(profile.bio) }
    var contact by remember(profile) { mutableStateOf(profile.contact) }
    var category by remember(profile) { mutableStateOf(profile.category) }
    var pendingPhoto by remember { mutableStateOf<Uri?>(null) }
    var removePhoto by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { pendingPhoto = uri; removePhoto = false }
    }
    val pickPhoto = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    val shownPhoto: Any? = when {
        removePhoto -> null
        pendingPhoto != null -> pendingPhoto
        else -> profile.photoPath
    }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = InkBlack)
            }
            Text("Edit Profile", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = InkBlack, modifier = Modifier.align(Alignment.Center))
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            Box(Modifier.clickable(onClick = { pickPhoto() })) {
                Avatar(size = 96.dp, model = shownPhoto)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(30.dp)
                        .background(PurpleGray, CircleShape).border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.PhotoCamera, contentDescription = "Ganti foto", tint = Color.White, modifier = Modifier.size(15.dp)) }
            }
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { pickPhoto() }) { Text("Change Photo", color = PurpleGray, fontSize = 13.sp) }
                if (shownPhoto != null) {
                    TextButton(onClick = { pendingPhoto = null; removePhoto = true }) { Text("Remove", color = InkGray, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            LabeledField("Name", name, { name = it }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            LabeledField("Username", username, { username = it.replace(" ", "").replace("@", "") }, Modifier.fillMaxWidth(), prefix = "@")
            Spacer(Modifier.height(16.dp))
            LabeledField("Bio", bio, { bio = it }, Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
            Spacer(Modifier.height(16.dp))
            LabeledField("Contact", contact, { contact = it }, Modifier.fillMaxWidth(), keyboardType = KeyboardType.Email)
            Spacer(Modifier.height(16.dp))
            CategoryDropdown(category, SampleData.categories, { category = it }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(24.dp))
        }

        Button(
            enabled = !saving,
            onClick = {
                when {
                    name.isBlank() -> Toast.makeText(context, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show()
                    username.isBlank() -> Toast.makeText(context, "Username tidak boleh kosong", Toast.LENGTH_SHORT).show()
                    else -> {
                        saving = true
                        onSave(ProfileEdit(name.trim(), username.trim(), bio.trim(), contact.trim(), category, pendingPhoto, removePhoto)) { photoOk ->
                            val msg = if (photoOk) "Data berhasil disimpan" else "Data disimpan, tetapi foto gagal dimuat"
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            onBack()
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp).height(52.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PurpleGray, contentColor = Color.White)
        ) {
            Text(if (saving) "Saving..." else "Save Changes", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

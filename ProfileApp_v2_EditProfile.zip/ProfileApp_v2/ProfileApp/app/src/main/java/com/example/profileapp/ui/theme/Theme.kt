package com.example.profileapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PurpleGray = Color(0xFF5E5A7A)
val InkBlack = Color(0xFF111111)
val InkGray = Color(0xFF6B6B76)
val BorderGray = Color(0xFFD9D9DF)

private val Scheme = lightColorScheme(
    primary = PurpleGray,
    onPrimary = Color.White,
    background = Color.White,
    surface = Color.White,
    onBackground = InkBlack,
    onSurface = InkBlack,
    outline = BorderGray
)

@Composable
fun ProfileAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

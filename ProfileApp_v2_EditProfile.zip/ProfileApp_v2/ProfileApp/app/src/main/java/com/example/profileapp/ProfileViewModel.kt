package com.example.profileapp

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.profileapp.data.ProfileEdit
import com.example.profileapp.data.ProfileRepository
import com.example.profileapp.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ProfileViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ProfileRepository(app)

    var profile: UserProfile by mutableStateOf(repo.load())
        private set

    /** Menyimpan hasil edit. onDone(true) jika semua sukses, false jika foto gagal diproses (teks tetap tersimpan). */
    fun saveEdit(edit: ProfileEdit, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            var photo = profile.photoPath
            var photoOk = true
            withContext(Dispatchers.IO) {
                if (edit.removePhoto) {
                    repo.deletePhoto(photo); photo = null
                } else if (edit.newPhoto != null) {
                    val path = repo.storePhoto(edit.newPhoto)
                    if (path != null) { repo.deletePhoto(photo); photo = path } else photoOk = false
                }
            }
            profile = profile.copy(
                name = edit.name, username = edit.username, bio = edit.bio,
                contact = edit.contact, category = edit.category, photoPath = photo
            )
            repo.save(profile)
            onDone(photoOk)
        }
    }

    fun toggleFollow() {
        profile = profile.copy(isFollowing = !profile.isFollowing)
        repo.save(profile)
    }
}

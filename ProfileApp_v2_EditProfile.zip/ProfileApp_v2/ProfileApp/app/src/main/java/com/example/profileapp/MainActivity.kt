package com.example.profileapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.profileapp.ui.screens.EditProfileScreen
import com.example.profileapp.ui.screens.ProfileScreen
import com.example.profileapp.ui.theme.ProfileAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProfileAppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.White) { AppNav() }
            }
        }
    }
}

@Composable
fun AppNav(vm: ProfileViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "profile") {
        composable("profile") {
            ProfileScreen(
                profile = vm.profile,
                onEdit = { nav.navigate("edit") { launchSingleTop = true } },
                onToggleFollow = vm::toggleFollow
            )
        }
        composable("edit") {
            EditProfileScreen(
                profile = vm.profile,
                onSave = { edit, done -> vm.saveEdit(edit, done) },
                onBack = { nav.popBackStack() }
            )
        }
    }
}
